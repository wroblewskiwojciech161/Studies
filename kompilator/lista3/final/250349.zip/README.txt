==========================================
Wojciech Wróblewski 250349
=========================================
lista3 laboratorium kursu jftt
==========================================
Zad1
==========================================
kompilacja

> make

przykładowe uruchomienie
>./calculator 

po uruchomieniu kalkulator
rozpoczyna swoje działanie
i można aplikować formuły

=========================================
Zad2
========================================
kompilacja i przykładowe uruchomienie

>python3 calculator.py 


po uruchomieniu można aplikować
formuły


