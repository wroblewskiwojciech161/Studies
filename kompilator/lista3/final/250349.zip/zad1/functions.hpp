long long int ring_mod(long long int a, int p);
long long int pow(int b, int n, int p);
long long int modularInverse(int a, int m);
long long int gcdExtended(int a, int b, int *x, int *y);
std::string addToDisplay(std::string output, std::string data);