Wojciech Wróblewski 250349
====================================
nr indeksu. 250349
====================================
Jezyki Formalne i Teroria Translacji
====================================
lista2
====================================



====================================
zad1
====================================
Sposob uruchomienia.
$>  make
$> ./zad1 < <dane testowe>

dla danych testowych data.txt
$>  make
$>  ./zad1 < data.txt

Rozwiązanie zostanie przepisane do
pliku output.txt

====================================
zad2
====================================
Sposob uruchomienia.
$>  make
$> ./zad2 < <dane testowe>

dla danych testowych data.py
$>  make
$>  ./zad2 < data.py

Rozwiązanie zostanie przepisane do
pliku output.py

====================================
zad3
====================================

Sposob uruchomienia.
$>  make
$> ./zad3 < <dane testowe> <flaga>

gdy checemy zachować komentarze dokumentacyjne
dodajemy flagę -documentation


dla danych testowych test.cpp
$>  make
$>  ./zad3 < test.cpp

albo 

dla danych testowych test.cpp
$>  make
$>  ./zad3 < test.cpp -documentation

Rozwiązanie zostanie przepisane do
pliku output.cpp


====================================
zad4
====================================

Sposob uruchomienia.
$>  make
$> ./zad4 
