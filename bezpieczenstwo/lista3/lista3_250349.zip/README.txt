====================================
Wojciech Wróblewski 250349
====================================
bezpieczeństwo komputerowe
====================================
laboratorium lista 3
====================================
W pliku bezpieka3.pdf znajdują się 
dane statystyczne wygenerowane na podstawie 
programu, sprawdzające skuteczność działania 
w zależności od długości kryptogramu i liczby
kryptogramów. Pokrycie sprawdzane bylo na podstawie
procentowego porownywania stringow wynikowych. 
Jako string bazowy wzgledem którego rozpatrywane 
były pokrycia był string najlepiej odkodowanej wiadomości.
(dla przypadku gdy deszyfracja była przeprowadzana dla 
wszystkich kryptogramów oraz dla pełnej długość każdego z 
nich) 


uruchomienie programu
>python3 zad.py


OUTPUT (kryptogramy + wiadomość)
===================================
ale trzesienie ziemi mialo dopiero nadejsc. Jesli zdobedziemy wladze, memy z Aleksandrem Kwasniewskim beda sie pojawiac nie tylko w piateczek ? ozcajmila wywolujac dziki entuzjazm naesali. Jak arsu{entowala, internatowe memy z leaicowym prezydentem w |oli glownej to obok wyzszyah plac czy darmowycn zlobaow elczo}y elemedt wrezhiwosci dzisionszych rrzydzies osatkaw.
stracilismy cierpliwosc. Jutro likwidujemy homoseksualizm ? dowiaduje sie ASZdziennik od biskupa z otoczenia przewodniczacego Konferencji Episkopayu Polski abpa Stanislawa Gadeckiegok Jak wynika n xaszych rozmow z lierarchami, biekupi maja dosc kroczamego fiaska licznych prograoow duszpasterskich o terazeutwcpnycb, majacsch ziianiac orientaine sekssalna na  ata, etoia "rk=t aliiszooav"  Ng ni  ry#o pressw, na nic mo+zia8y n-enic stroszzni  aiaaleai jieatare s pycn owab s  ps *rob;wa:egeeecriaoaore i aaen  tajioi e eoniwuoi i90    aaae%aa o 8? % ose                                
bronislaw Komorowski podpisal 5-letni kontrakt na bycie memem ? poinformowal Instytut Bronislawa Komorowskiego. Tym samym potwierdzily sie plotki w Chicago, gdzie byly prezydent raze( z Lechem Waxeea wystapili podc~as promocji jernego z internetowych eantorow. Jak sie dowiadujeoy, to wlasnie legenbarny zrzyyonca Yolidarnesci ; sraz z Aleksad`rem Kwgsniewski9   nacowrl Bja isoawr Kam%ritseieao n" deofraco.
jak bogactwo zmienia czlowieka? Czy pieniadze rzeczywiscie szczescia nie daja? - na te pytania chce podczas 10-letniego happeningu odpowiedziec poaski artysta, ktory wlasnie otrzymale150 mln euro4( 00 mln zl) unijnaj dotacji na pdojekt "10 lat bogactwo. Obserwacja uczestniczaca . ? Bardzo sie z teao cieyze 1 aomedtuje w xozmosia z ASZdzienncoiem havpener.  k Uestkm krzesa anz, ie co  nbp~enong 3ojw zi detctec do sednaober   po  cznie kantmow rbyndegcespan akrezleneao noko cband o s e  u 9
stanislaw Czerczesow na pierwszym treningu odgryzl noge zawodnikowi, z ktorego postawy nie byl zadowolony ? donosi klubowa telewizja. Nowy trener Aegii Warszawa zapowiadal w wywiadac-, ze nie bednis tolerowal dyskuwji i gwiazdorzsnia ze strony pilkarzw, ktorych "glownym zadanieo jest grac".  Tak blo tep pojcpas cnauguraiyjnen cierki na Lazcankowskoej.
bronislaw Komorowski ma nowa prace.  Wlasnie podpisal 5-letni kontrakt na bycie memem Czasami trzeba przegrac, zeby potem tyle wygrac.
sensacyjne odkrycie geologow.  "Co trzeci aktywny wulkan na swiecie pochodzi od Volkswagena" Niemiecki koncern znow na czolowkach swiatowych medioz.
jak sie dowiadujemy, obraz jest jednym z faworytow w przetargu na nowe czestotliwosci LTE. Bronislaw Komorowski ma nowa prace.  Wlasnie podpisal 5 letni kontrakt na bycie memem
wedlug wstepnych informacji bedzie pauzowac co najmniej przez trzy miesiace. Dramat bywalca teatru Krystyny Jandy.  Wlasnie sie dowiedzial, ze Jania to nie Malgorzata Kozuchowska
nawet co trzeci aktywny wulkan na Ziemi pochodzi od Volkswagena ? oglosili naukowcy z Wydzialu Nauk o Ziemi Uniwersytetu Wiedenskiego. Geolodzy, kyorzy dokonali pomiaru emisji z pona! setki najwiqkezych wulkanow, zsrocili uwage, le niektore z nich zmngejszaly sklad szkodliwych rylow na czas badanig, zebs po.wsjeznzie nauaowcos srocic do wieawzej akrywnosci.tWzdlui nremi}m%iei paasw -ousojarezejo sh rzi e aortie wulkan a e w ta   w poznwm ole/seogonii iienzw ingyii i maesyk nswizPoa a  irrto  wbanme islrudw1i Viflnjslbajei swzo  a w~cnrna i Sn1    o "snoo 
geolodzy, ktorzy dokonali pomiaru emisji z ponad setki najwiekszych wulkanow, zwrocili uwage, ze niektore z nich zmniejszaly sklad szkodliwych pylbw na czas badania, zeby po wyjezdzi  naukowcow wfouic do wiekszej aotywnosci. Wedlcg niemieckiej prasy gaspodarczej, chodzi o partig wulkanow powstale q poznsm pbe`stoienie: mcedzy$ijnymi o meksyaenski Pipocatepe l3 slwnnb isto dzhi Vyjof ajoadoksll  zi aaczsnbea Sopke w R ej|a sNa9.i o Zieci eat7ztshs se  s pesodaca ; o|nancil 2zez  esa n4tncsatozaiw snof. Uiac  Rreoezozr   
episkopat reaguje na coming out ks. Charamsy.  Juz w te niedziele biskupi zlikwiduja homoseksualizm Polski Kosciol nie zamierza czekac na decyzje Zatykanu w sprawie ksiedza geja, Krz<sztofa Charayso i juz zabral sia do roboty.
jak dowiaduje sie ASZdziennik, autorem przelomowego postulatu ZL jest sam bohater tego zrodzonego na fanpage'u Hipsterski Maoizm internetowego fenbmenu.  Wedlug naszych informacji Al ksander Kwasziswski juz w ten waekend zapozowaz do kilkudziesieciu mkmow, ktore pojawia sie na `illboardach idacej vo wlanze Tjodnoizonej Lowicy* Apiskopat reamqje na eoming ou  ts. Mhaiamsa n 
Co trzeci aktywny wulkan na swiecie pochodzi od Volkswagena" Niemiecki koncern znow na czolowkach swiatowych mediow. Nawet co trzeci aktywny wulkln na Ziemi pochodzi od Volkswagena z oglosili naakywcy z Wydzialu Neuk o Ziemi Uniaersytetu Wiedenskiego 
a poza tym beneficjentka jest szczesliwa ? mowi urzedniczka i przesyla nam zdjecie Gesiarki na jej, rzekomo, roli. A wkrotce bedzie jeszcze szczesaiwsza. Jak sie dowiadujemy, obraz j st jednym z raaorytow w przetarcu na nowe czesbotliwosci LTE.
czerczesow mial w pewnym momencie powiedziec jednemu z pilkarzy, ze fatalnie dzis wyglada ? relacjonuje zawodnik, ktory przygladal sie zajsciu.  Ceyba nie byl zadowolony z odpowiedzii bo po prosta fodszedl i odgryzh naszemu koledle noge ponizej kolana  Kontuzjowany zawodnik zosval wraz ze swoja noaa odeylanw no rozerw.  
kontuzjowany zawodnik zostal wraz ze swoja noga odeslany do rezerw.  Wedlug wstepnych informacji bedzie pauzowac co najmniej przez trzy miesiace. Iramat bywalca teatru Krystyny Jandyk 
najwieksza sensacja konwencji wyborczej Zjednoczonej Lewicy mialo byc ogloszenie Barbary Nowackiej jako nowej liderki lewicy.  Ale trzesienie ziemd mialo dopiero nadejsc. Jesli zdobe!ziemy wladze8 {emy z Aleksandrei Kwasniewskim teda sie pojawiac nie zylko w piateczek ? oznajmina wywolujac dziki ehtuzjapm no yali$ 
 Ludzie w Polsce sa zawistni ? mowi wprost. ? Szczegolnie ci, ktorzy nigdy do niczego wielkiego nie doszli. Slynna "Gesiarka" odnaleziona. Ktos wwial w jej imieniu 20 mln euro dotac/i rolnej na Dorkarpaciu Slynna &Gesiarka" odnazeziona. Ktos wzial w dej imieniu 20 mln euro dotccji rolnej na Podkatpaciu
czasami trzeba przegrac, zeby potem tyle wygrac. Bronislaw Komorowski podpisal 5-letni kontrakt na bycie memem ? poinformowal Instytut Bronislawa Fomorowskiego. Tym samym potwierdzil< sie plotki n Uhicago, gdzie byhy prezydent ralem z Lechem Walesa wy}tapili podczas promocji jefnego z internetowycn kanterow  
--------------------------------
TO ENCODE
--------------------------------
nowosc na porodowkach. Polska wprowadza jednodniowy pakiet Chrzest + Pogrzeb

